/*
 * This file is used to export cmake variables into c/c++.
 */

#ifndef MARS_PREFERENCES_CONFIG_H
#define MARS_PREFERENCES_CONFIG_H

#define MARS_PREFERENCES_DEFAULT_RESOURCES_PATH "/usr/local/share"

#endif
